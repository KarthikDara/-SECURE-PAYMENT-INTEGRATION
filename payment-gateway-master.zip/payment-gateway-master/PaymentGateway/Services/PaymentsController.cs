﻿using System;
namespace PaymentGateway.Services
{
    public class PaymentsController
    {
        public PaymentsController()
        {
        }
    }
}
