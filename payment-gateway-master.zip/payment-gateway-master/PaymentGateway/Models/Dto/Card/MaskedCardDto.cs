﻿namespace PaymentGateway.Models.Dto.Card
{
    public class MaskedCardDto
    {
        public string CardNumber { get; set; }
        public string CardHolderName { get; set; }
    }
}
