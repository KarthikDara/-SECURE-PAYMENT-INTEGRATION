﻿namespace PaymentGateway.Models.Dto.Payment
{
    public class PaymentResponseDto
    {
        public int Id { get; set; }
        public PaymentStatus Status { get; set; }
    }
}
