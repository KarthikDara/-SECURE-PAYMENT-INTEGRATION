﻿using System;
namespace PaymentGateway.Models
{
    public class PaymentStatus
    {
        public PaymentStatus()
        {
        }
    }
}
